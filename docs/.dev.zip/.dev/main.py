from cryptography.fernet import Fernet
import json

# Generate key sekali saja dan simpan aman
key = Fernet.generate_key()
print(f"Secret key (save this safely!): {key.decode()}")

# Buat instance Fernet dengan key
cipher_suite = Fernet(key)

# Contoh konfigurasi DB
DB_CONFIG = {
    'host': "localhost",
    'user': "root",
    'password': "",
    'database': "users_key",
    'port': 3306
}

# Serialize config ke JSON dan enkripsi
config_json = json.dumps(DB_CONFIG).encode()
encrypted_config = cipher_suite.encrypt(config_json)

# Simpan ke file
with open("db_config.enc", "wb") as f:
    f.write(encrypted_config)

print("Encrypted DB config saved to db_config.enc")
